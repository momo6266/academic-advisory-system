$(document).ready(function(){
    $.ajax({
      url : "http://localhost/UTAR%20Academic%20Advisory%20System/performance.php?username=S0616",
      type : "GET",
      success : function(data){
        console.log(data);
        data = JSON.parse(data);

        var sem = [];
        var gpad = [];
        var cgpad = [];

        for(var i in data) {
            sem.push("Sem" + data[i].sem);
            gpad.push(data[i].gpa);
            cgpad.push(data[i].cgpa);
        }

        var chartdata = {
            labels: sem,
            datasets: [
                {
                    label: "gpa",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "rgba(59, 89, 152, 0.75)",
                    borderColor: "rgba(59, 89, 152, 1)",
                    pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
                    pointHoverBorderColor: "rgba(59, 89, 152, 1)",
                    data: gpad
                  }, 
                  {
                    label: "cgpa",
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: "rgba(29, 202, 255, 0.75)",
                    borderColor: "rgba(29, 202, 255, 1)",
                    pointHoverBackgroundColor: "rgba(29, 202, 255, 1)",
                    pointHoverBorderColor: "rgba(29, 202, 255, 1)",
                    data: cgpad
                  }
            ]
        };

        var ctx = $("#mycanvas");

        var LineGraph = new Chart(ctx, {
            type: 'line',
            data: chartdata
        });
     
      },
      error : function(data) {
  
      }
    });
});