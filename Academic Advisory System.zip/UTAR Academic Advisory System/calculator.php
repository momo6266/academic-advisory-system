<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Calculator</title>

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="bootstrap.min.css" />

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="style.css" />


</head>



<body>
<html>

<head>
    <style>
        .chart-container {
            width: 640px;
            height: auto;
        }
    </style>
</head>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Student Academic Performance</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="bootstrap.min.css" />

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="style.css" />

    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>


</head>


<body id="page-top">

    <?php
    $host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "mydatabase";  
    
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }
    $username = $_GET['username'];
    //to prevent from mysqli injection  
    $username = stripcslashes($username);  
    $username = mysqli_real_escape_string($con, $username);  
    ?>



    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="mainpage.php?username=<?php echo $username?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Student Portal</div>
                
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="mainpage.php?username=<?php echo $username?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="index.php">Login</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
            aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-fw fa-wrench"></i>
            <span>Advisor Appointments</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="advisor.php?username=<?php echo $username?>">Timetable</a>
                <a class="collapse-item" href="app_req.php?username=<?php echo $username?>">Requests</a>
                <a class="collapse-item" href="available_time.php?username=<?php echo $username?>">Available Timeslot</a>
                
            </div>
        </div>
    </li>
            <!-- Nav Item - Tables -->
          
            <li class="nav-item">
                <a class="nav-link" href="tables.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-table"></i>
                    <span>Consultation Report</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="stuinfo.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-table"></i>
                    <span>Student Information</span></a>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Student Academic Performance</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="performance.php?username=<?php echo $username?>">Graph</a>
                        <a class="collapse-item" href="subject.php?username=<?php echo $username?>">Subject</a>
                        <a class="collapse-item" href="calculator.php?username=<?php echo $username?>">Calculator</a>
                        
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="monthlyprogressstudent.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Monthly Progress Report</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <table border="1" cellspacing="5" bgcolor="white" style="background: silver;float: left; margin-left: 300px">

        <tr>
            <th>Subject</th>
            <th>Marks</th>
            <th>Credit Hours</th>
        </tr>
        <tr style="background: silver;">
            <td>Subject 1</th>
            <td><select id="sub1" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre1" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 2</th>
            <td><select id="sub2" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre2" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 3</th>
            <td><select id="sub3" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre3" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 4</th>
            <td><select id="sub4" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre4" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 5</th>
            <td><select id="sub5" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre5" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 6</th>
            <td><select id="sub6" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre6" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 7</th>
            <td><select id="sub7" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre7" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr>
            <th colspan="5" height="50" style="background: silver;">
                <input type="submit" value="Calculate" onclick="Sub()" style="float: right; margin-right: 14px">
            </th>
        </tr>
    </table>

    <table border="1" cellspacing="5" bgcolor="white" style="background: silver;float: right; margin-right: 300px">

        <tr>
            <th>Result</th>
            <th>Marks</th>
            <th>Credit Hours</th>
        </tr>
        <tr style="background: silver;">
            <td>GPA</th>
            <td><input type="number" id="GPA" value="0"></td>
            <td><input type="number" id="creGPA" value="0"></td>
        </tr>
        <tr style="background: silver;">
            <td>CGPA</th>
            <td><input type="number" id="CGPA" value="0"></td>
            <td><input type="number" id="creCGPA" value="0"></td>
        </tr>
        <tr>
            <th colspan="5" height="50" style="background: silver;">
                <input type="submit" value="Calculate" onclick="cal()" style="float: right; margin-right: 14px">
            </th>
        </tr>
    </table>

    <div class="list" style=" padding-top: 50px;">


        <TABLE width="85%" style="float:bottom; margin-top: 350px; margin-left: 150px">

            <TR>
                <TD colspan="10"><b><U>Grading System</U></b></TD>
            </TR>
            <TR valign="top">
                <TD width="5%">A+</TD>
                <TD width="15%">4.0000</TD>

                <TD width="5%">A</TD>
                <TD width="15%">4.0000</TD>

                <TD width="5%">A-</TD>
                <TD width="15%">3.6700</TD>

                <TD width="5%">B+</TD>
                <TD width="15%">3.3300</TD>

                <TD width="5%">B</TD>
                <TD width="15%">3.0000</TD>

            </TR>
            <TR valign="top">
                <TD>B-</TD>
                <TD>2.6700</TD>

                <TD>C+</TD>
                <TD>2.3300</TD>

                <TD>C</TD>
                <TD>2.0000</TD>

                <TD>F</TD>
                <TD>FAIL</TD>

                <TD>W</TD>
                <TD>WITHDRAWN</TD>

            </TR>

            <TR valign="top">
                <TD>AB </TD>
                <TD>ABSENT</TD>

                <TD>EX </TD>
                <TD>EXEMPTED </TD>

                <TD>BR </TD>
                <TD>BARRED </TD>

                <TD>I</TD>
                <TD>INCOMPLETE </TD>

                <TD>P</TD>
                <TD>IN PROGRESS</TD>

            </TR>
            <TR valign="top">
                <TD>RS </TD>
                <TD>RE-SIT </TD>

                <TD>RP </TD>
                <TD>REPEAT </TD>

                <TD>FL </TD>
                <TD>FAILED </TD>

                <TD>PS </TD>
                <TD>PASSED </TD>
                <TD>CT </TD>
                <TD>CREDIT TRANSFER </TD>


            </TR>
            <TR>
                <TD>AU </TD>
                <TD colspan='3'>AUDIT WITH EXAMINATION</TD>
                <TD>AN </TD>
                <TD colspan='3'>AUDIT WITHOUT EXAMINATION</TD>
            </TR>

        </TABLE>
    </div>

    <script type="text/javascript">

        function Sub() {
            var subj1 = 0, subj2 = 0, subj3 = 0, subj4 = 0, subj5 = 0, subj6 = 0, subj7 = 0, hour1 = 0, hour2 = 0, hour3 = 0, hour4 = 0, hour5 = 0, hour6 = 0, hour7 = 0, gpamark = 0, gpahour = 0, tgpa = 0;
            subj1 = parseFloat(document.getElementById('sub1').value);
            subj2 = parseFloat(document.getElementById('sub2').value);
            subj3 = parseFloat(document.getElementById('sub3').value);
            subj4 = parseFloat(document.getElementById('sub4').value);
            subj5 = parseFloat(document.getElementById('sub5').value);
            subj6 = parseFloat(document.getElementById('sub6').value);
            subj7 = parseFloat(document.getElementById('sub7').value);
            hour1 = parseFloat(document.getElementById('cre1').value);
            hour2 = parseFloat(document.getElementById('cre2').value);
            hour3 = parseFloat(document.getElementById('cre3').value);
            hour4 = parseFloat(document.getElementById('cre4').value);
            hour5 = parseFloat(document.getElementById('cre5').value);
            hour6 = parseFloat(document.getElementById('cre6').value);
            hour7 = parseFloat(document.getElementById('cre7').value);


            // Calculating gpa
            gpamark = subj1 * hour1 + subj2 * hour2 + subj3 * hour3 + subj4 * hour4 + subj5 * hour5 + subj6 * hour6 + subj7 * hour7;
            gpahour = hour1 + hour2 + hour3 + hour4 + hour5 + hour6 + hour7;
            tgpa = gpamark / gpahour;

            // Displaying the Student Data
            alert("The GPA is: " + tgpa.toFixed(4));
        }

        function cal() {
            var ggpa, ccgpa, gpacred, cgpacred, tomarks, tocred, fcgpa;
            ggpa = parseFloat(document.getElementById('GPA').value);
            ccgpa = parseFloat(document.getElementById('CGPA').value);
            gpacred = parseFloat(document.getElementById('creGPA').value);
            cgpacred = parseFloat(document.getElementById('creCGPA').value);

            tomarks = ggpa * gpacred + ccgpa * cgpacred;
            tocred = gpacred + cgpacred;
            fcgpa = tomarks / tocred;

            alert("The CGPA is: " + fcgpa.toFixed(4));

        }


    </script>


  

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="index.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
    <br>

    <table border="1" cellspacing="5" bgcolor="white" style="background: silver;float: left; margin-left: 300px">

        <tr>
            <th>Subject</th>
            <th>Marks</th>
            <th>Credit Hours</th>
        </tr>
        <tr style="background: silver;">
            <td>Subject 1</th>
            <td><select id="sub1" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre1" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 2</th>
            <td><select id="sub2" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre2" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 3</th>
            <td><select id="sub3" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre3" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 4</th>
            <td><select id="sub4" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre4" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 5</th>
            <td><select id="sub5" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre5" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 6</th>
            <td><select id="sub6" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre6" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr style="background: silver;">
            <td>Subject 7</th>
            <td><select id="sub7" style="width:211px">
                    <option value="0"></option>
                    <option value="4">A+</option>
                    <option value="4">A</option>
                    <option value="3.67">A-</option>
                    <option value="3.33">B+</option>
                    <option value="3">B</option>
                    <option value="2.67">B-</option>
                    <option value="2.33">C+</option>
                    <option value="2">C</option>
                    <option value="0">F</option>
                </select></td>
            <td><input type="number" id="cre7" value="0" min="0" max="4" style="width:211px"></td>
        </tr>
        <tr>
            <th colspan="5" height="50" style="background: silver;">
                <input type="submit" value="Calculate" onclick="Sub()" style="float: right; margin-right: 14px">
            </th>
        </tr>
    </table>

    <table border="1" cellspacing="5" bgcolor="white" style="background: silver;float: right; margin-right: 300px">

        <tr>
            <th>Result</th>
            <th>Marks</th>
            <th>Credit Hours</th>
        </tr>
        <tr style="background: silver;">
            <td>GPA</th>
            <td><input type="number" id="GPA" value="0"></td>
            <td><input type="number" id="creGPA" value="0"></td>
        </tr>
        <tr style="background: silver;">
            <td>CGPA</th>
            <td><input type="number" id="CGPA" value="0"></td>
            <td><input type="number" id="creCGPA" value="0"></td>
        </tr>
        <tr>
            <th colspan="5" height="50" style="background: silver;">
                <input type="submit" value="Calculate" onclick="cal()" style="float: right; margin-right: 14px">
            </th>
        </tr>
    </table>

    <div class="list" style=" padding-top: 50px;">


        <TABLE width="85%" style="float:bottom; margin-top: 350px; margin-left: 150px">

            <TR>
                <TD colspan="10"><b><U>Grading System</U></b></TD>
            </TR>
            <TR valign="top">
                <TD width="5%">A+</TD>
                <TD width="15%">4.0000</TD>

                <TD width="5%">A</TD>
                <TD width="15%">4.0000</TD>

                <TD width="5%">A-</TD>
                <TD width="15%">3.6700</TD>

                <TD width="5%">B+</TD>
                <TD width="15%">3.3300</TD>

                <TD width="5%">B</TD>
                <TD width="15%">3.0000</TD>

            </TR>
            <TR valign="top">
                <TD>B-</TD>
                <TD>2.6700</TD>

                <TD>C+</TD>
                <TD>2.3300</TD>

                <TD>C</TD>
                <TD>2.0000</TD>

                <TD>F</TD>
                <TD>FAIL</TD>

                <TD>W</TD>
                <TD>WITHDRAWN</TD>

            </TR>

            <TR valign="top">
                <TD>AB </TD>
                <TD>ABSENT</TD>

                <TD>EX </TD>
                <TD>EXEMPTED </TD>

                <TD>BR </TD>
                <TD>BARRED </TD>

                <TD>I</TD>
                <TD>INCOMPLETE </TD>

                <TD>P</TD>
                <TD>IN PROGRESS</TD>

            </TR>
            <TR valign="top">
                <TD>RS </TD>
                <TD>RE-SIT </TD>

                <TD>RP </TD>
                <TD>REPEAT </TD>

                <TD>FL </TD>
                <TD>FAILED </TD>

                <TD>PS </TD>
                <TD>PASSED </TD>
                <TD>CT </TD>
                <TD>CREDIT TRANSFER </TD>


            </TR>
            <TR>
                <TD>AU </TD>
                <TD colspan='3'>AUDIT WITH EXAMINATION</TD>
                <TD>AN </TD>
                <TD colspan='3'>AUDIT WITHOUT EXAMINATION</TD>
            </TR>

        </TABLE>
    </div>

    <script type="text/javascript">

        function Sub() {
            var subj1 = 0, subj2 = 0, subj3 = 0, subj4 = 0, subj5 = 0, subj6 = 0, subj7 = 0, hour1 = 0, hour2 = 0, hour3 = 0, hour4 = 0, hour5 = 0, hour6 = 0, hour7 = 0, gpamark = 0, gpahour = 0, tgpa = 0;
            subj1 = parseFloat(document.getElementById('sub1').value);
            subj2 = parseFloat(document.getElementById('sub2').value);
            subj3 = parseFloat(document.getElementById('sub3').value);
            subj4 = parseFloat(document.getElementById('sub4').value);
            subj5 = parseFloat(document.getElementById('sub5').value);
            subj6 = parseFloat(document.getElementById('sub6').value);
            subj7 = parseFloat(document.getElementById('sub7').value);
            hour1 = parseFloat(document.getElementById('cre1').value);
            hour2 = parseFloat(document.getElementById('cre2').value);
            hour3 = parseFloat(document.getElementById('cre3').value);
            hour4 = parseFloat(document.getElementById('cre4').value);
            hour5 = parseFloat(document.getElementById('cre5').value);
            hour6 = parseFloat(document.getElementById('cre6').value);
            hour7 = parseFloat(document.getElementById('cre7').value);


            // Calculating gpa
            gpamark = subj1 * hour1 + subj2 * hour2 + subj3 * hour3 + subj4 * hour4 + subj5 * hour5 + subj6 * hour6 + subj7 * hour7;
            gpahour = hour1 + hour2 + hour3 + hour4 + hour5 + hour6 + hour7;
            tgpa = gpamark / gpahour;

            // Displaying the Student Data
            alert("The GPA is: " + tgpa.toFixed(4));
        }

        function cal() {
            var ggpa, ccgpa, gpacred, cgpacred, tomarks, tocred, fcgpa;
            ggpa = parseFloat(document.getElementById('GPA').value);
            ccgpa = parseFloat(document.getElementById('CGPA').value);
            gpacred = parseFloat(document.getElementById('creGPA').value);
            cgpacred = parseFloat(document.getElementById('creCGPA').value);

            tomarks = ggpa * gpacred + ccgpa * cgpacred;
            tocred = gpacred + cgpacred;
            fcgpa = tomarks / tocred;

            alert("The CGPA is: " + fcgpa.toFixed(4));

        }


    </script>


</body>