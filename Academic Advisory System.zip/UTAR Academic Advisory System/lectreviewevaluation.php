<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student View</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">
    <?php
    $host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "mydatabase";  
    
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }
    
    $username = $_GET['username'];
    $Session = $_GET['Session'];
    $StudentID = $_GET['StudentID'];
    $CourseID = $_GET['CourseID'];
    ?>  

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="lectmainpage.php?username=<?php echo $username?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Lecturers Portal</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="lectmainpage.php?username=<?php echo $username?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="index.php">Login</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Advisor Timetable</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="advisor.php?username=<?php echo $username?>">Timetable</a>
                        <a class="collapse-item" href="request.php?username=<?php echo $username?>">Request</a>
                        <a class="collapse-item" href="available_time.php?username=<?php echo $username?>">Available Timeslot</a>
                        
                    </div>
                </div>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="lecturerconsultation.php?username=<?php echo $username?>">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Consultation Report</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Student Academic Performance</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="select.php?username=<?php echo $username?>">Select Student</a>
                        <a class="collapse-item" href="performancel.php?username=<?php echo $username?>">Graph</a>
                        <a class="collapse-item" href="subjectl.php?username=<?php echo $username?>">Subject</a>
                        
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="monthlyprogresslect.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Monthly Progress Report</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <?php      

                        $sql = "select * from stuinfo where StudentID = '$StudentID'";  
                        $result = mysqli_query($con, $sql);  
                        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                        $count = mysqli_num_rows($result);
                        
                    ?>
                    
                    <h1 class="h3 mb-2 text-gray-800">Review Evaluation Report</h1>
                    <p class="mb-4">
                    <table style="width:100%">
                        <tr>
                            <th style="width:20%">Name:</th>
                            <td><?php echo $row['Name']; ?></td>
                            <td rowspan = "6"><?php echo '<img src="data:image;base64,'.base64_encode($row['Picture']).'" alt="Picture" style = "width:160px; height:200px;">'?></td>  
                        </tr>
                        <tr>
                            <th>Student ID:</th>
                            <td><?php echo $row['StudentID']; ?></td>
                        </tr>
                        <tr>
                            <th>Gender:</th>
                            <td><?php echo $row['Gender']; ?></td>
                        </tr>
                        <tr>
                            <th>Current Session:</th>
                            <?php $session = $row['Study Session']?>
                            <td><?php echo $session; ?></td>
                        </tr>
                        <tr>
                            <th>Programme:</th>
                            <td><?php echo $row['Course']; ?></td>
                        </tr>
                        <tr>
                            <th>NRIC No.:</th>
                            <td><?php echo $row['NRIC No.']; ?></td>
                        </tr>
                    </table>
                    <br>
                    




                        <!-- DataTales Example -->
                        <div class="tab">
                            <button class="btn btn-primary" onclick="displayinfo(event, '10')">October</button>
                            <button class="btn btn-primary" onclick="displayinfo(event, '11')">November</button>
                            <button class="btn btn-primary" onclick="displayinfo(event, '12')">December</button>
                        </div>
                    <br>
                    <div id="10" class="tabcontent">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Evaluation Overview</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <?php
                                        $sql = "select * from rating where Session = '$Session' and CourseID = '$CourseID' and StudentID = '$StudentID' and Month = '10'";
                                        $result = mysqli_query($con, $sql);
                                        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);
                                        $month = 12;
                                        ?>
                                        <tr>
                                            <th>No.</th>
                                            <th>Section Name</th>
                                            <th>Mark</th>
                                            <th>Feedback</th>
                                            <th>Overall Feedback</th>
                                            <th>Lecturer Feedback</th>
                                        </tr>
                                    </thead>
                                    <?php
                                        $depth=$row1["Depth"];
                                        $mark1=strval($depth);
                                        if ($depth<1)
                                        {
                                            $mark1=strval("NA");
                                        }

                                        $Content=$row1["Content"];
                                        $mark2=strval($Content);
                                        if ($Content<1)
                                        {
                                            $mark2=strval("NA");
                                        }

                                        $Assignment=$row1["Assignment"];
                                        $mark3=strval($Assignment);
                                        if ($Assignment<1)
                                        {
                                            $mark3=strval("NA");
                                        }

                                        $Assessment=$row1["Assessment"];
                                        $mark4=strval($Assessment);
                                        if ($Assessment<1)
                                        {
                                            $mark4=strval("NA");
                                        }
                                        $Class=$row1["Class"];
                                        $mark5=strval($Class);
                                        if ($Class<1)
                                        {
                                            $mark5=strval("NA");
                                        }
                                        $Facility=$row1["Facility"];
                                        $mark6=strval($Facility);
                                        if ($Facility<1)
                                        {
                                            $mark6=strval("NA");
                                        }
                                        $Room=$row1["Room"];
                                        $mark7=strval($Room);
                                        if ($Room<1)
                                        {
                                            $mark7=strval("NA");
                                        }
                                    ?>


                                    <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Depth</td>
                                        <td><?php echo $mark1?> / 5</td>
                                        <td><?php echo $row1["DepthFeedback"]?></td>
                                        <td rowspan = '7'><?php echo $row1["StudentFeedback"]?></td>
                                        <td rowspan = '7'><?php echo $row1["LectFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Content</td>
                                        <td><?php echo $mark2?> / 5</td>
                                        <td><?php echo $row1["ContentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Assignment</td>
                                        <td><?php echo $mark3?> / 5</td>
                                        <td><?php echo $row1["AssignmentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>Assessment</td>
                                        <td><?php echo $mark4?> / 5</td>
                                        <td><?php echo $row1["AssessmentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>Class</td>
                                        <td><?php echo $mark5?> / 5</td>
                                        <td><?php echo $row1["ClassFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>Facility</td>
                                        <td><?php echo $mark6?> / 5</td>
                                        <td><?php echo $row1["FacilityFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>Room</td>
                                        <td><?php echo $mark7?> / 5</td>
                                        <td><?php echo $row1["RoomFeedback"]?></td>
                                    </tr>

                                    </tbody>
                                </table>
                                <form class="evaluationfeedback" name = "evaluationfeedback" action = "submitlectevaluationfeedback.php" method = "POST">
                        
                                    <div class="form-group">
                                        <input type="hidden" name ="username" id="username" rows="3" cols="90" value="<?php echo $username?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name ="StudentID" id="StudentID" rows="3" cols="90" value="<?php echo $StudentID?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name ="Session" id="Session" rows="3" cols="90" value="<?php echo $session?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name ="month" id="month" rows="3" cols="90" value="<?php echo $month?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name ="CourseID" id="CourseID" rows="3" cols="90" value="<?php echo $CourseID?>">
                                    </div>
                                    <div class="form-group">
                                    <textarea id="lectfeedback" placeholder="Write your feedback here...."name="lectfeedback" rows="3" cols="90" style="overflow: hidden; border: 0px none; height: 56px; width: 559px;"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary btn-user btn-block"
                                            id="btn" value = "Submit Review Feedback" style="height:46px; width:400px; font-size: 16px; right:20px;">
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                    


                    <div id="11" class="tabcontent">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Evaluation Overview</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <?php
                                        $sql = "select * from rating where Session = '$Session' and CourseID = '$CourseID' and StudentID = '$StudentID' and Month = '11'";
                                        $result = mysqli_query($con, $sql);
                                        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);
                                        $month = 11;
                                        ?>
                                        <tr>
                                            <th>No.</th>
                                            <th>Section Name</th>
                                            <th>Mark</th>
                                            <th>Feedback</th>
                                            <th>Overall Feedback</th>
                                            <th>Lecturer Feedback</th>
                                        </tr>
                                    </thead>
                                    <?php
                                        $depth=$row1["Depth"];
                                        $mark1=strval($depth);
                                        if ($depth<1)
                                        {
                                            $mark1=strval("NA");
                                        }

                                        $Content=$row1["Content"];
                                        $mark2=strval($Content);
                                        if ($Content<1)
                                        {
                                            $mark2=strval("NA");
                                        }

                                        $Assignment=$row1["Assignment"];
                                        $mark3=strval($Assignment);
                                        if ($Assignment<1)
                                        {
                                            $mark3=strval("NA");
                                        }

                                        $Assessment=$row1["Assessment"];
                                        $mark4=strval($Assessment);
                                        if ($Assessment<1)
                                        {
                                            $mark4=strval("NA");
                                        }
                                        $Class=$row1["Class"];
                                        $mark5=strval($Class);
                                        if ($Class<1)
                                        {
                                            $mark5=strval("NA");
                                        }
                                        $Facility=$row1["Facility"];
                                        $mark6=strval($Facility);
                                        if ($Facility<1)
                                        {
                                            $mark6=strval("NA");
                                        }
                                        $Room=$row1["Room"];
                                        $mark7=strval($Room);
                                        if ($Room<1)
                                        {
                                            $mark7=strval("NA");
                                        }
                                    ?>


                                    <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Depth</td>
                                        <td><?php echo $mark1?> / 5</td>
                                        <td><?php echo $row1["DepthFeedback"]?></td>
                                        <td rowspan = '7'><?php echo $row1["StudentFeedback"]?></td>
                                        <td rowspan = '7'><?php echo $row1["LectFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Content</td>
                                        <td><?php echo $mark2?> / 5</td>
                                        <td><?php echo $row1["ContentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Assignment</td>
                                        <td><?php echo $mark3?> / 5</td>
                                        <td><?php echo $row1["AssignmentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>Assessment</td>
                                        <td><?php echo $mark4?> / 5</td>
                                        <td><?php echo $row1["AssessmentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>Class</td>
                                        <td><?php echo $mark5?> / 5</td>
                                        <td><?php echo $row1["ClassFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>Facility</td>
                                        <td><?php echo $mark6?> / 5</td>
                                        <td><?php echo $row1["FacilityFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>Room</td>
                                        <td><?php echo $mark7?> / 5</td>
                                        <td><?php echo $row1["RoomFeedback"]?></td>
                                    </tr>

                                    </tbody>
                                </table>
                                <form class="evaluationfeedback" name = "evaluationfeedback" action = "submitlectevaluationfeedback.php" method = "POST">
                        
                                        <div class="form-group">
                                            <input type="hidden" name ="username" id="username" rows="3" cols="90" value="<?php echo $username?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="StudentID" id="StudentID" rows="3" cols="90" value="<?php echo $StudentID?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="Session" id="Session" rows="3" cols="90" value="<?php echo $session?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="month" id="month" rows="3" cols="90" value="<?php echo $month?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="CourseID" id="CourseID" rows="3" cols="90" value="<?php echo $CourseID?>">
                                        </div>
                                        <div class="form-group">
                                        <textarea id="lectfeedback" placeholder="Write your feedback here...."name="lectfeedback" rows="3" cols="90" style="overflow: hidden; border: 0px none; height: 56px; width: 559px;"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-primary btn-user btn-block"
                                                id="btn" value = "Submit Review Feedback" style="height:46px; width:400px; font-size: 16px; right:20px;">
                                        </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    </div>

                    <div id="12" class="tabcontent">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Evaluation Overview</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <?php
                                        $sql = "select * from rating where Session = '$Session' and CourseID = '$CourseID' and StudentID = '$StudentID' and Month = '12'";
                                        $result = mysqli_query($con, $sql);
                                        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);
                                        $month = 12;
                                        ?>
                                        <tr>
                                            <th>No.</th>
                                            <th>Section Name</th>
                                            <th>Mark</th>
                                            <th>Feedback</th>
                                            <th>Overall Feedback</th>
                                            <th>Lecturer Feedback</th>
                                        </tr>
                                    </thead>
                                    <?php
                                        $depth=$row1["Depth"];
                                        $mark1=strval($depth);
                                        if ($depth<1)
                                        {
                                            $mark1=strval("NA");
                                        }

                                        $Content=$row1["Content"];
                                        $mark2=strval($Content);
                                        if ($Content<1)
                                        {
                                            $mark2=strval("NA");
                                        }

                                        $Assignment=$row1["Assignment"];
                                        $mark3=strval($Assignment);
                                        if ($Assignment<1)
                                        {
                                            $mark3=strval("NA");
                                        }

                                        $Assessment=$row1["Assessment"];
                                        $mark4=strval($Assessment);
                                        if ($Assessment<1)
                                        {
                                            $mark4=strval("NA");
                                        }
                                        $Class=$row1["Class"];
                                        $mark5=strval($Class);
                                        if ($Class<1)
                                        {
                                            $mark5=strval("NA");
                                        }
                                        $Facility=$row1["Facility"];
                                        $mark6=strval($Facility);
                                        if ($Facility<1)
                                        {
                                            $mark6=strval("NA");
                                        }
                                        $Room=$row1["Room"];
                                        $mark7=strval($Room);
                                        if ($Room<1)
                                        {
                                            $mark7=strval("NA");
                                        }
                                    ?>


                                    <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Depth</td>
                                        <td><?php echo $mark1?> / 5</td>
                                        <td><?php echo $row1["DepthFeedback"]?></td>
                                        <td rowspan = '7'><?php echo $row1["StudentFeedback"]?></td>
                                        <td rowspan = '7'><?php echo $row1["LectFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Content</td>
                                        <td><?php echo $mark2?> / 5</td>
                                        <td><?php echo $row1["ContentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Assignment</td>
                                        <td><?php echo $mark3?> / 5</td>
                                        <td><?php echo $row1["AssignmentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>Assessment</td>
                                        <td><?php echo $mark4?> / 5</td>
                                        <td><?php echo $row1["AssessmentFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>Class</td>
                                        <td><?php echo $mark5?> / 5</td>
                                        <td><?php echo $row1["ClassFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>Facility</td>
                                        <td><?php echo $mark6?> / 5</td>
                                        <td><?php echo $row1["FacilityFeedback"]?></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>Room</td>
                                        <td><?php echo $mark7?> / 5</td>
                                        <td><?php echo $row1["RoomFeedback"]?></td>
                                    </tr>

                                    </tbody>
                                </table>
                                <form class="evaluationfeedback" name = "evaluationfeedback" action = "submitlectevaluationfeedback.php" method = "POST">
                        
                                        <div class="form-group">
                                            <input type="hidden" name ="username" id="username" rows="3" cols="90" value="<?php echo $username?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="StudentID" id="StudentID" rows="3" cols="90" value="<?php echo $StudentID?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="Session" id="Session" rows="3" cols="90" value="<?php echo $session?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="month" id="month" rows="3" cols="90" value="<?php echo $month?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name ="CourseID" id="CourseID" rows="3" cols="90" value="<?php echo $CourseID?>">
                                        </div>
                                        <div class="form-group">
                                        <textarea id="lectfeedback" placeholder="Write your feedback here...."name="lectfeedback" rows="3" cols="90" style="overflow: hidden; border: 0px none; height: 56px; width: 559px;"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-primary btn-user btn-block"
                                                id="btn" value = "Submit Review Feedback" style="height:46px; width:400px; font-size: 16px; right:20px;">
                                        </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    </div>


                


                     

                </div>

            

                        

        
        <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="index.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <script>
    function displayinfo(evt, adviseetabinfo) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(adviseetabinfo).style.display = "block";
    evt.currentTarget.className += " active";
    }
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>