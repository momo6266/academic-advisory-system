<nav id="nav">
    <div id="nav">
        <ul>
            <li>
                <a href="#"><img src="img/utar.jpg" width="112" height="56"> </a>
            </li>
            <li><a class="nav-link" href="performance.php?username=<?php echo $username?>" >CGPA Graph</a></li>
            <li><a class="nav-link" href="subject.php?username=<?php echo $username?>" >Subject Result</a></li>
            <li><a class="nav-link" href="calculator.php?username=<?php echo $username?>" >Result Calculator</a></li>

        </ul>
    </div>
</nav>
