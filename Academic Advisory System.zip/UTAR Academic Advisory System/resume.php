<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>

	<title>Resume</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />

	<meta name="keywords" content="" />
	<meta name="description" content="" />

	<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.7.0/build/reset-fonts-grids/reset-fonts-grids.css" media="all" /> 
	<link rel="stylesheet" type="text/css" href="css/resume.css" media="all" />

</head>
<body>
<?php
    $host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "mydatabase";
    
    $username = $_GET['username'];

    
    
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    } 
    ?>

<?php                 
                $sql = "select * from stuinfo where StudentID ='$username'";  
                $result = mysqli_query($con, $sql);  
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                $count = mysqli_num_rows($result);
                
            ?> 

<div id="doc2" class="yui-t7">
	<div id="inner">
	
		<div id="hd">
			<div class="yui-gc">
				<div class="yui-u first">
					<h2><?php echo $row['Name'];?></h2>
					<h3><?php echo $row['Course'];?></h3>
				</div>

				<div class="yui-u">
					<div class="contact-info">
						<h3><a id="pdf" href="#" download>Download </a></h3>
						
					</div><!--// .contact-info -->
				</div>

				
			</div><!--// .yui-gc -->
		</div><!--// hd -->

		<div id="bd">
			<div id="yui-main">
				<div class="yui-b">

				<div class="yui-gf">
						<div class="yui-u first">
							<h2>Profile</h2>
						</div>
						<div class="yui-u">
						<div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <?php
                                        
                                        $sql = "select * from stuinfo where StudentID = '$username'";
                                        $result = mysqli_query($con, $sql);
                                        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC)
                                        ?>
                                        <tr>
                                            <th colspan=2>Student ID</th>
                                            <td colspan=2><?php echo $row1["StudentID"]?></td>
                                        </tr>
										<tr>
                                            <th colspan=2>Gender</th>
                                            <td colspan=2><?php echo $row1["Gender"]?></td>
                                        </tr>
										<tr>
                                            <th colspan=2>Race</th>
                                            <td colspan=2><?php echo $row1["Race"]?></td>
                                        </tr>
										<tr>
                                            <th colspan=2>Nationality</th>
                                            <td colspan=2><?php echo $row1["Nationality"]?></td>
                                        </tr>
                                        <tr>
                                            <th colspan=2>UTAR Email</th>
                                            <td colspan=2><?php echo $row1["University Email"]?></td>
                                        </tr>
                                        <tr>
                                            <th colspan=2>Address</th>
                                            <td colspan=2><?php echo $row1["Address"]?></td>
                                        </tr>
                                        <tr>
                                            <th colspan=2>Postcode</th>
                                            <td colspan=2><?php echo $row1["Postal Code"]?></td>
                                        </tr>
                                        <tr>
                                            <th colspan=2>State</th>
                                            <td colspan=2><?php echo $row1["G.State"]?></td>
                                        </tr>
                                        <tr>
                                            <th colspan=4>Contact No.</th>
                                        </tr>
                                        <tr>
                                            <th>Home:</th>
                                            <td><?php echo $row1["G.Contact Number"]?></td>
                                            <th>Mobile:</th>
                                            <td><?php echo $row1["Phone Number"]?></td>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
					</div>

					</div><!--// .yui-gf -->
					<div class="yui-gf">
						<div class="yui-u first">
							<h2>Curriclar</h2>
						</div>
						<div class="yui-u">
							<p class="enlarge">
							<div id="CurricularInfo" class="tabcontent">
                    <div class="card shadow mb-4">
                        
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Society</th>
                                            <th>Position</th>
                                            <th>Status</th>
                                            <th>From</th>
											<th>To</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        
                                        $sql = "select * from curricular where StudentID ='$username'";
                                        $result = mysqli_query($con, $sql);  
                                        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);
                                         
                                        ?>
                                        
                                         <tr>
                                            <td><?php echo $row1["Society"]?></td>
                                            <td><?php echo $row1["Position"]?></td>
                                            <td><?php echo $row1["Status"]?></td>
                                            <td><?php echo $row1["From"]?></td>
											<td>-</td>
                                        </tr>

                                        
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
							</p>
						</div>
					</div><!--// .yui-gf -->

					</div>


					<div class="yui-gf">
						<div class="yui-u first">
							<h2>SoftSkills Infromation</h2>
						</div>
						<div class="yui-u">
						<div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Soft Skills</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th colspan=4>Points Earned</th>
                                        </tr>
                                        <tr>
                                            <th>No</th>
                                            <th>Components</th>
                                            <th>Points Earned</th>
                                            <th>Accumulated Points Earned</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        
                                        $sql = "select * from softskill where StudentID = '$username'";
                                        $result = mysqli_query($con, $sql);
                                        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);
                                        ?>
                                        
                                         <tr>
                                            <td><?php echo "1"?></td>
                                            <td><?php echo "Cognitive Skills"?></td>
                                            <td><?php echo $row1["Cognitive Skills"]?></td>

                                            <?php 
                                            $ttlpt=$row1["Cognitive Skills"];
                                            $skill1=$row1["Cognitive Skills"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "2"?></td>
                                            <td><?php echo "Communication and Language Skills"?></td>
                                            <td><?php echo $row1["Communication & Language skills"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Communication & Language skills"];
                                            $skill2=$row1["Communication & Language skills"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "3"?></td>
                                            <td><?php echo "Complex Problem Solving"?></td>
                                            <td><?php echo $row1["Complex Problem Solving"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Complex Problem Solving"];
                                            $skill3=$row1["Complex Problem Solving"];
                                            ?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "4"?></td>
                                            <td><?php echo "Critical Thinking"?></td>
                                            <td><?php echo $row1["Critical Thinking"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Critical Thinking"];
                                            $skill4=$row1["Critical Thinking"];?>
                                            
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "5"?></td>
                                            <td><?php echo "Digital Literacy"?></td>
                                            <td><?php echo $row1["Digital Literacy"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Digital Literacy"];
                                            $skill5=$row1["Digital Literacy"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "6"?></td>
                                            <td><?php echo "Emotional Intelligence, Cultural Intelligence & Teamwork"?></td>
                                            <td><?php echo $row1["Emotional Intelligence, Cultural Intelligence & Teamwork"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Emotional Intelligence, Cultural Intelligence & Teamwork"];
                                            $skill6=$row1["Emotional Intelligence, Cultural Intelligence & Teamwork"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "7"?></td>
                                            <td><?php echo "Entrepreneurship Skills"?></td>
                                            <td><?php echo $row1["Entrepreneurship Skills"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Entrepreneurship Skills"];
                                            $skill7=$row1["Entrepreneurship Skills"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "8"?></td>
                                            <td><?php echo "Leadership Skills"?></td>
                                            <td><?php echo $row1["Leadership Skills"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Leadership Skills"];
                                            $skill8=$row1["Leadership Skills"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "9"?></td>
                                            <td><?php echo "Lifelong Learning & Information Management"?></td>
                                            <td><?php echo $row1["Lifelong Learning & Information Management"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Lifelong Learning & Information Management"];
                                            $skill9=$row1["Lifelong Learning & Information Management"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "10"?></td>
                                            <td><?php echo "Moral and Professional Ethics"?></td>
                                            <td><?php echo $row1["Moral and Professional Ethics"]?></td>
                                            <?php $ttlpt=$ttlpt + $row1["Moral and Professional Ethics"];
                                            $skill10=$row1["Moral and Professional Ethics"];?>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>

                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <tr>
                                            <td><?php echo "Total Points Earned"?></td>
                                            <td><?php echo $ttlpt?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo "Grading Category"?></td>
                                            <?php

                                            if (($skill1||$skill2||$skill3||$skill4||$skill5||$skill6||$skill7||$skill8||$skill9||$skill0||$skill10) == 0)
                                            $grade="Not Eligible";
                                            else
                                            {
                                                if ($ttlpt==100)
                                                $grade="Pass";

                                                else if ($ttlpt<100)
                                                $grade="Not Eligible";

                                                else if ($ttlpt<126)
                                                $grade="Merit";

                                                else if ($ttlpt<151)
                                                $grade="Distiction";

                                                else
                                                $grade="Platinum";
                                            }
                                            ?>
                                            <td><?php echo $grade?></td>
                                        </tr>
                                        </table>
                                        <?php
                                        $result->free();
                                        ?>
                                        
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
					</div>
					

					
						
					</div><!--// .yui-gf-->Universiti Tunku Abdul Rahman Kampar Campus - Perak, Malaysia</h2>
							
						</div>
					</div><!--// .yui-gf -->


				</div><!--// .yui-b -->
			</div><!--// yui-main -->
		</div><!--// bd -->

		<!--// footer -->

	</div><!-- // inner -->


</div><!--// doc -->


</body>
</html>