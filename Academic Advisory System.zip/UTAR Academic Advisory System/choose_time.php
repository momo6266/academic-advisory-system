<?php
session_start();
	include("connection.php");
	include("functions.php");

?>

<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" rel="stylesheet">

        <style>
            .app-time {
  border: 1px solid #fff;
  padding: 20px 30px;
  box-shadow: 2px 4px 10px 0px #c7cacce3;
}

.option-input {
  -webkit-appearance: none;
  -moz-appearance: none;
  -ms-appearance: none;
  -o-appearance: none;
  appearance: none;
  position: relative;
  top: 5px;
  right: 0;
  bottom: 0;
  left: 40px;
  height: 20px;
  width: 20px;
  transition: all 0.15s ease-out 0s;
  background: #fff;
  border: 1px solid #999;
  color: #fff;
  cursor: pointer;
  display: inline-block;
  margin-right: 0.5rem;
  outline: none;
  position: relative;
  z-index: 1000;
}
.option-input:hover {
  background: #e5e7eb;
}
.option-input:checked {
  border: 1px solid #fff;
}
.option-input:checked::before {
  color: #d9486d;
  height: 40px;
  width: 40px;
  position: absolute;
  content: "✔";
  display: inline-block;
  font-size: 12px;
  left: 4px;
  line-height: 20px;
}
.option-input:checked::after {
  -webkit-animation: click-wave 0.65s;
  -moz-animation: click-wave 0.65s;
  animation: click-wave 0.65s;
  background: #40e0d0;
  content: "";
  display: block;
  position: relative;
  z-index: 100;
}

.option-input.radio {
  border-radius: 50%;
}
.option-input.radio::after {
  border-radius: 50%;
}
.app-check {
  display: flex;
}
.app-border {
  border: 1px solid #ece9e9;
  border-radius: 7px;
  padding: 5px 7px 5px 9px;
  padding-left: 40px;
  min-height: 30px;
}

.option-input.radio:checked + .app-border {
  background: #d9486d;
}
.option-input.radio:disabled,
.option-input.radio:disabled + .app-border {
  cursor: not-allowed;
  opacity: 0.6;
}
.app-label {
  position: relative;
  top: 5px;
  margin-right: 10px;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');



.container{
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

button{
    width: 270px;
    height: 80px;
    border: none;
    outline: none;
    background: #2f2f2f;
    color: #fff;
    font-size: 22px;
    border-radius: 40px;
    text-align: center;
    box-shadow: 0 6px 20px -5px rgba(0,0,0,0.4);
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.check-box{
    width: 80px;
    height: 80px;
    border-radius: 40px;
    box-shadow: 0 0 12px -2px rgba(0,0,0,0.5);
    position: absolute;
    top: 0;
    right: -40px;
    opacity: 0;
}

.check-box svg{
    width: 40px;
    margin: 20px;
}

svg path{
    stroke-width: 3;
    stroke: #fff;
    stroke-dasharray: 34;
    stroke-dashoffset: 34;
    stroke-linecap: round;
}


.active .check-box{
    right: 0;
    opacity: 1;
    transition: 1s;
}

.active p{
    margin-right: 125px;
    transition: 1s;
}

.active svg path{
    stroke-dashoffset: 0;
    transition: 1s;
    transition-delay: 1s;
}
            </style>
    </head>
    <body>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
        <div class="container">
          <a class="navbar-brand" href="#">
            <img src="images/utar.jpg" alt="..." height="36">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="advisee.php">Advisee's Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="choose_time.php">Appointment Request</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="available_time.php">View Timeslot</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Advisee
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="#">List</a></li>
                  <li><a class="dropdown-item" href="#">View CGPA</a></li>
                  <li>
                    <hr class="dropdown-divider">
                  </li>
                  <li><a class="dropdown-item" href="#">Something else here</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>



      <h1>Choose a timeslot</h1>

        <div class="app-time">
            <div>
              <p>Monday</p>
              <p>9:00AM to 12:00PM</p>
              <form>
              <div class="app-check">
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio"  name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">10:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">10:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">11:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">11:30 AM
                  </label>
                </div>
              </div>
            </div>
            <div>
              <p>Tuesday</p>
              <p>9:00AM to 12:00PM</p>
              <form>
              <div class="app-check">
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio"  name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">10:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">10:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">11:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">11:30 AM
                  </label>
                </div>
              </div>
            </div>
            <div>
              <p>Wednesday</p>
              <p>9:00AM to 12:00PM</p>
              <form>
              <div class="app-check">
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio"  name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">10:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">10:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">11:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">11:30 AM
                  </label>
                </div>
              </div>
            </div>
            <div>
              <p>Thursday</p>
              <p>9:00AM to 12:00PM</p>
              <form>
              <div class="app-check">
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio"  name="example" />
                <div class="app-border">
          
                  <label class="app-label">9:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">10:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">10:30 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">11:00 AM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">11:30 AM
                  </label>
                </div>
              </div>
            </div>
            <div>
              <p>Friday</p>
              <p>1:00PM to 5:00PM</p>
              <div class="app-check">
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">1:00 PM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">1:30 PM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">2:00 PM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">2:30 PM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">3:00 PM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">3:30 PM
                  </label>
                </div>
                <input type="radio" class="option-input radio" name="example" />
                <div class="app-border">
          
                  <label class="app-label">4:00 PM
                  </label>
                </div>
          
                <input type="radio" class="option-input radio" name="example"  />
                <div class="app-border">
          
                  <label class="app-label">4:30 PM
                  </label>
                </div>
          
              </div>
            </div>

          </div>
          <br><br><div class="container">
            <button id="btn">
                <p id="btnText">Submit</p>
                <div class="check-box">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                        <path fill="transparent" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
                    </svg>
                </div>
            </button>
        </div>
        <script type="text/javascript">
            const btn = document.querySelector("#btn");
            const btnText = document.querySelector("#btnText");
    
            btn.onclick = () => {
                btnText.innerHTML = "Thanks";
                btn.classList.add("active");
            };
        </script>
          </form>
    </body>
    </html>