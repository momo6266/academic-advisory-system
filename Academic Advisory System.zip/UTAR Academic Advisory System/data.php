<?php
include('connection9.php');
session_start();

$dquery = sprintf("SELECT gpa,cgpa,sem from semresult WHERE studentid = '$_SESSION[id]' ORDER BY sem ASC");

$result = $con->query($dquery);

$data = array();
foreach($result as $row){
    $data[] = $row;
}

$result->close();

$con->close();

print json_encode($data);

?>
