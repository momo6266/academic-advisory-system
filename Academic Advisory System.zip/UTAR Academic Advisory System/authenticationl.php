<?php      
session_start();
    include('connection9.php');  
    $stui = $_POST['stuid'];
        //to prevent from mysqli injection  
        $stui = stripcslashes($stui);  
        $stui = mysqli_real_escape_string($con, $stui);  
      
        $sql = "select *from semresult where studentid = '$stui'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
        $_SESSION["stuii"] = $stui;
        $username = $_SESSION["id"];
        
        
          
        if($count >= 1){  
            echo " <script> window.location.href='performancel.php?username=$username'; </script>"; 
        }  
        else{
    echo "<script> alert('Please Insert Correct Student ID');</script>";
    
            echo "<script> window.location.href='select.php?username=$username'; </script>";  
        }     
?>  