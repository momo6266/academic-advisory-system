<?php

    
    function performQuery($query){
        include('connection.php');
        $stmt=$con->prepare($query);
        if($stmt->execute()){
            return true;
        }
            else{
            return false;
        }
    }

    // function fetchAll($query){
    //     include('connection.php');
    //     $stmt = mysqli_query($con,$query);
    //     $stmt=$con->query($query);
    //     return  $stmt->fetch_all();
    // }
?>
