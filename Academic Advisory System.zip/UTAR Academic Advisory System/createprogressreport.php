<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student View</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

<?php
    $host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "mydatabase";  
    
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }
    $username = $_GET['username'];
    $month = $_GET['month'];
    $CourseID = $_GET['CourseID'];
    $Session = $_GET['Session'];
    //to prevent from mysqli injection  
    $username = stripcslashes($username);  
    $username = mysqli_real_escape_string($con, $username);  
    ?>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="mainpage.php?username=<?php echo $username?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Student Portal</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="mainpage.php?username=<?php echo $username?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
            
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="index.php">Login</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
            aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-fw fa-wrench"></i>
            <span>Advisor Appointments</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="advisor.php?username=<?php echo $username?>">Timetable</a>
                <a class="collapse-item" href="app_req.php?username=<?php echo $username?>">Requests</a>
                <a class="collapse-item" href="available_time.php?username=<?php echo $username?>">Available Timeslot</a>
                
            </div>
        </div>
    </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Advisee Appointments</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="advisee.php?username=<?php echo $username?>">Timetable</a>
                        <a class="collapse-item" href="advisee_req.php?username=<?php echo $username?>">Requests</a>
                        <a class="collapse-item" href="available_time.php?username=<?php echo $username?>">Lecturer Timetable</a>
                        
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="tables.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-table"></i>
                    <span>Consultation Report</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="stuinfo.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-table"></i>
                    <span>Student Information</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Student Academic Performance</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="performance.php?username=<?php echo $username?>">Graph</a>
                        <a class="collapse-item" href="subject.php?username=<?php echo $username?>">Subject</a>
                        <a class="collapse-item" href="calculator.php?username=<?php echo $username?>">Calculator</a>
                        
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="monthlyprogressstudent.php?username=<?php echo $username?>" >
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Monthly Progress Report</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <?php 
                    
                        $sql = "select * from rating r inner join course c on c.CourseID = r.CourseID where r.StudentID = '$username' and r.CourseID = '$CourseID' and r.Month = '$month' and r.Session = '$Session'";  
                        $result = mysqli_query($con, $sql);  
                        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  

                    ?>
                    
                    <h1 class="h3 mb-2 text-gray-800">Monthly Progress Report</h1>
                    <p class="mb-4">
                        <h4 class="h4 mb-2 text-gray-800">Course Evaluation</h4>
                    <table style="width:100%">
                        <tr>
                            <th width=10%>Course ID and Name:</th>
                            <td><?php echo $row['CourseID']; ?> <?php echo $row["CourseName"]?></td>
                        </tr>
                        <tr>
                            <th>Session:</th>
                            <td><?php echo $row['Session']; ?></td>
                        </tr>

                    </table>
                    <br>              

                    <div class="card-header py-3">
                        <h4 class="m-0 font-weight-bold text-primary">1) Course Facilities Evaluation</h4>
                        <br><h5><strong>Ratings of Selected Programme Aspects</strong></h5>
                        <p>Please provide a rating for each aspect of the teaching of this course based on your experience. 
                            Please indicate how strongly you agree or disagree with a statement, guided by the following scale.
                        <br><br>Strongly Agree : 5 <br> Agree : 4 <br> Neither Agree nor Disagree : 3 <br> Disagree : 2 <br> Strongly Disagree : 1 <br> Not Applicable : NA</p>
                        
                    </div>
                    
                    <form name ="submitprogressreport" action="submitprogressreport.php" method = "POST">
                    
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="background-color: #ffffff;">
                        <tr style="background-color: #0a1e59;">
                            <th width=3% rowspan="2">No.</th>
                            <th width=34% rowspan="2">Programme Aspects</th>
                            <th colspan="6">Rating</th>
                            <th rowspan="2">Feedback</th>

                        </tr>
                        <tr style="background-color: #0a1e59;">
                            <th width=3%>5</th>
                            <th width=3%>4</th>
                            <th width=3%>3</th>
                            <th width=3%>2</th>
                            <th width=3%>1</th>
                            <th width=3%>NA</th>
                        </tr>
                        <tr>
                            <td width=3%>1</td>
                            <td width=34%>The depth of coverage for the course matched my expectation.</td>
                            <td width=3%><input type="radio" name ="depth" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="depth" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="depth" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="depth" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="depth" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="depth" id="0" value="0"></td>
                            <td width=3%><textarea name ="depthfeedback" id="depthfeedback" placeholder="Feedback"></textarea></td>
                        </tr>
                        <tr>
                            <td width=3%>2</td>
                            <td width=34%>The content of the course was appropriate at the level of study.</td>
                            <td width=3%><input type="radio" name ="content" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="content" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="content" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="content" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="content" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="content" id="0" value="0"></td>
                            <td width=3%><textarea name ="contentfeedback" id="contentfeedback" placeholder="Feedback"></textarea></td>
                        </tr>
                        <tr>
                            <td width=3%>3</td>
                            <td width=34%>Assignments, tutorials and practical were adequate.</td>
                            <td width=3%><input type="radio" name ="assignment" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="assignment" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="assignment" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="assignment" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="assignment" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="assignment" id="0" value="0"></td>
                            <td width=3%><textarea name ="assignmentfeedback" id="assignmentfeedback" placeholder="Feedback"></textarea></td>
                        </tr>
                        <tr>
                            <td width=3%>4</td>
                            <td width=34%>The assessments given were adequate.</td>
                            <td width=3%><input type="radio" name ="assessment" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="assessment" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="assessment" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="assessment" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="assessment" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="assessment" id="0" value="0"></td>
                            <td width=3%><textarea name ="assessmentfeedback" id="assessmentfeedback" placeholder="Feedback"></textarea></td>
                        </tr>
                        <tr>
                            <td width=3%>5</td>
                            <td width=34%>The classes for the course were properly scheduled</td>
                            <td width=3%><input type="radio" name ="class" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="class" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="class" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="class" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="class" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="class" id="0" value="0"></td>
                            <td width=3%><textarea name ="classfeedback" id="classfeedback" placeholder="Feedback"></textarea></td>
                        </tr>

                    </table>
                    <hr>

                    <div class="card-header py-3">
                        <h4 class="m-0 font-weight-bold text-primary">2) Course Facilities Evaluation</h4>
                        <br><h5><strong>Ratings of Selected Programme Aspects</strong></h5>
                        <p>Please provide a rating for each aspect of the teaching of this course based on your experience. 
                            Please indicate how strongly you agree or disagree with a statement, guided by the following scale.
                        <br><br>Strongly Agree : 5 <br> Agree : 4 <br> Neither Agree nor Disagree : 3 <br> Disagree : 2 <br> Strongly Disagree : 1 <br> Not Applicable : NA</p>
                    </div>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="background-color: #ffffff;">
                        <tr style="background-color: #0a1e59;">
                            <th width=3% rowspan="2">No.</th>
                            <th width=34% rowspan="2">Programme Aspects</th>
                            <th colspan="6">Rating</th>
                            <th rowspan="2">Feedback</th>
                        </tr>
                        <tr style="background-color: #0a1e59;">
                            <th width=3%>5</th>
                            <th width=3%>4</th>
                            <th width=3%>3</th>
                            <th width=3%>2</th>
                            <th width=3%>1</th>
                            <th width=3%>NA</th>
                        </tr>
                        <tr>
                            <td width=3%>1</td>
                            <td width=34%>The teaching facilities were sufficiently provided.</td>
                            <td width=3%><input type="radio" name ="facility" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="facility" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="facility" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="facility" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="facility" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="facility" id="0" value="0"></td>
                            <td width=3%><textarea name ="facilityfeedback" id="facilityfeedback" placeholder="Feedback"></textarea></td>
                        </tr>
                        <tr>
                            <td width=3%>2</td>
                            <td width=34%>The teaching room environment was conducive for learning. </td>
                            <td width=3%><input type="radio" name ="room" id="5" value="5"></td>
                            <td width=3%><input type="radio" name ="room" id="4" value="4"></td>
                            <td width=3%><input type="radio" name ="room" id="3" value="3"></td>
                            <td width=3%><input type="radio" name ="room" id="2" value="2"></td>
                            <td width=3%><input type="radio" name ="room" id="1" value="1"></td>
                            <td width=3%><input type="radio" name ="room" id="0" value="0"></td>
                            <td width=3%><textarea name ="roomfeedback" id="roomfeedback" placeholder="Feedback"></textarea></td>
                        </tr>

                    </table>
                    <br>

                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Feedback</h6>
                    </div>

                        <div class="form-group">
                            <input type="text" name ="feedback" id="feedback" rows="3" cols="90" style="border: 0px none; height: 56px; width: 559px; position:relative; " placeholder="Write your feedback here...">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name ="CourseID" id="CourseID" rows="3" cols="90" value="<?php echo $CourseID?>">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name ="username" id="username" rows="3" cols="90" value="<?php echo $username?>">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name ="Session" id="Session" rows="3" cols="90" value="<?php echo $Session?>">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name ="month" id="month" rows="3" cols="90" value="<?php echo $month?>">
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary btn-user btn-block" style="height:46px; width:400px; font-size: 16px; right:20px;"
                                id="btn" value = "Submit Evaluation">
                        </div>

                        
                    </form>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="index.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>


</body>

</html>