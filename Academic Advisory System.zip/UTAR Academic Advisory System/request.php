<?php
session_start();

  include("connection.php");
	include("functions.php");

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" rel="stylesheet">
        <meta charset="utf-8">
        <style>
            .image{
                width:250px;
                height:300px;
                flex-basis: 40%;
            }
            img{
                max-width:100%;
            }
          
        
            a{
                text-decoration: none;
                }
            .accept {
                color: #FFF;
                background: #44CC44;
                padding: 15px 20px;
                box-shadow: 0 4px 0 0 #2EA62E;
                }
            .accept:hover {
                background: #6FE76F;
                box-shadow: 0 4px 0 0 #7ED37E;
                }
            .deny {
                color: #FFF;
                background: tomato;
                padding: 15px 20px;
                box-shadow: 0 4px 0 0 #CB4949;
                }
                .deny:hover {
                background: rgb(255, 147, 128);
                box-shadow: 0 4px 0 0 #EF8282;
                }
                .container1{
                    margin-left:30px;
                    margin-top:30px;
                    margin-bottom: 30px;
                }
        </style>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
            <div class="container">
              <a class="navbar-brand" href="#">
                <img src="images/utar.jpg" alt="..." height="36">
              </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="advisor.php">Advisor's Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="request.php">Appointment Requests</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="logout_advisor.php">Logout</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Advisee
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="#">List</a></li>
                      <li><a class="dropdown-item" href="#">View CGPA</a></li>
                      <li>
                        <hr class="dropdown-divider">
                      </li>
                      <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>

          <div class="container1"> 
            <div class="student" ><img class="image" src="images/sy.JPG"></div>
        <div>Name: Ng Shun Yi<div class="info"></div> </div>
        <div>Student ID: 200000<div class="info"></div></div>
        <div>Appointment Date: 11/15  <div class="info"></div></div>
        <div>Appointment Time: 10:00am  <div class="info"></div></div>
        <br>
        <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
        <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
        </div>
        <br>
        <div class="container1"> 
            <div class="student" ><img class="image" src="images/cc.JPG"></div>
        <div>Name: Cheah Chee Chun</div>
        <div>Student ID: 210000</div>
        <div>Appointment Date: 11/17  <div class="info"></div></div>
        <div>Appointment Time: 9:00am </div>
        <br>
        <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
        <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
        </div>
        <br>
        <div class="container1"> 
            <div class="student" ><img class="image" src="images/wj.JPG"></div>
        <div>Name: Lee Wei Jin</div>
        <div>Student ID: 220000</div>
        <div>Appointment Date: 11/13  <div class="info"></div></div>
        <div>Appointment Time: 12:00pm </div>
        <br>
        <a href="#" class="accept">ACCEPT <span class="fa fa-check"></span></a>
        <a href="#" class="deny">DENY <span class="fa fa-close"></span></a>
        </div>
        <br>

    </body>
</html>