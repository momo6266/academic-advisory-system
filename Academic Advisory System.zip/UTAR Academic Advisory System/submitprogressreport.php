<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Portal Login</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body>

<?php

$host = "localhost";  
$user = "root";  
$password = '';  
$db_name = "mydatabase";  
  
$con = mysqli_connect($host, $user, $password, $db_name);  
if(mysqli_connect_errno()) {  
    die("Failed to connect with MySQL: ". mysqli_connect_error());  
}

$CourseID = $_POST['CourseID'];
$username = $_POST['username'];
$Session = $_POST['Session'];
$month = $_POST['month'];

$depth= $_POST['depth'];
$content= $_POST['content'];
$assignment= $_POST['assignment'];
$assessment= $_POST['assessment'];
$class= $_POST['class'];
$facility= $_POST['facility'];
$room= $_POST['room'];
$depthfeedback= $_POST['depthfeedback'];
$contentfeedback= $_POST['contentfeedback'];
$assignmentfeedback= $_POST['assignmentfeedback'];
$assessmentfeedback= $_POST['assessmentfeedback'];
$classfeedback= $_POST['classfeedback'];
$facilityfeedback= $_POST['facilityfeedback'];
$roomfeedback= $_POST['roomfeedback'];

$feedback= $_POST['feedback'];


$sql = "update rating set Depth =('$depth') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set Content =('$content') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set Assignment =('$assignment') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set Assessment =('$assessment') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set Class =('$class') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set Facility =('$facility') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set Room =('$room') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set StudentFeedback =('$feedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set DepthFeedback =('$depthfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set ContentFeedback =('$contentfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set AssignmentFeedback =('$assignmentfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set AssessmentFeedback =('$assessmentfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set ClassFeedback =('$classfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set FacilityFeedback =('$facilityfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);
$sql = "update rating set RoomFeedback =('$roomfeedback') where StudentID = '$username' and CourseID = '$CourseID' and Month = '$month' and Session = '$Session'";
$run = mysqli_query($con,$sql);


?>


<table>
    <tr><a href = "mainpage.php?username=<?php echo $username?>"><button class="btn btn-primary" type="button">Click here to return to main page.</tr>
</table>


</body>

</html>