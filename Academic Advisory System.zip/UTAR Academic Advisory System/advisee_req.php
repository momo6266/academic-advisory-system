<?php
session_start();
    include('connection.php');
    include('functions.php');

    extract($_POST);
    $allday = isset($allday);


    $id2 = $_SESSION['stu_id'];
    if(isset($_POST['sent_advisee'])){
        // $req_title = $_POST['title'];
        // $req_start = $_POST['start_datetime'];
        // $req_end = $_POST['end_datetime'];
        $lec = $_POST['lec_id'];
        echo "<script> alert($lec) </script>" ;
            $query="INSERT INTO `advisee_req` (`stu_id`,`start_datetime`,`description`, `end_datetime`, `AID`) VALUES ('$id2', '$start_datetime', '$description', '$end_datetime', '$id')";
        

        if(performQuery($query)){
          echo '<script> alert("Your request has been sent! please wait for the confirmation from advisee :) "); </script>';
          echo "<script> location.replace('app_request.php') </script>";
    
        }
        else{
          echo '<script> alert("unknown error occured"); </script>';
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Appointment Requests</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

<div class="container">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-uppercase mb-0">Appointment Requests</h5>
            </div>
            <div class="table-responsive">
                <table class="table no-wrap user-table mb-0">
                  <thead>
                    <tr>
                      <th scope="col" class="border-0 text-uppercase font-medium">Name</th>
                      <th scope="col" class="border-0 text-uppercase font-medium">Student ID</th>
                      <th scope="col" class="border-0 text-uppercase font-medium">Email</th>
                      <th scope="col" class="border-0 text-uppercase font-medium">Appointment Date</th>
                      <!--<th scope="col" class="border-0 text-uppercase font-medium">End Date</th>!-->
                      <th scope="col" class="border-0 text-uppercase font-medium">Description</th>
                      <th scope="col" class="border-0 text-uppercase font-medium">Accept/Reject</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $query = "select * from advisee_req";
                    $result = mysqli_query($con,$query);
                    
                        if(mysqli_num_rows($result) > 0){
                            foreach($result->fetch_all(MYSQLI_ASSOC) as $row){
                                $stu = $row['stu_id'];
                                $query2 = "SELECT * from advisee where stu_id = '$stu'";
                                $st = $con->query($query2);
                                $result = mysqli_fetch_Assoc($st);
                        ?>
                    <tr>
                      <td>
                          <h5 class="font-medium mb-0"><?php echo $result['stu_name'] ?> </h5>
                      </td>
                      <td>
                          <span class="text-muted"><?php echo "$stu" ?></span><br>
                      </td>
                      <td>
                          <span class="text-muted"><?php echo $result['email'] ?></span><br>
                      </td>
                      <td>
                          <span class="text-muted"><?php echo $row['start_datetime'] ?></span><br>
                      </td>
                      <!--<td>
                      <span class="text-muted"><?php echo $row['end_datetime'] ?></span>
                    </td>!-->
                      <td>
                      <span class="text-muted">Consultation</span>
                    </td>
            <form method="post" action="advisee_req.php?a_r_id=<?php echo $row['a_r_id']?>&AID=<?php echo $row['AID']?>&start_datetime=<?php echo $row['start_datetime']?>&end_datetime=<?php echo $row['end_datetime']?>&description=<?php echo $row['description']?>">
                    <td>
                        <div id="button_container">


                      <button id="submit" type="submit" name="submit" class="btn btn-outline-info btn-circle btn-lg btn-circle ml-2"><i class="fa fa-check"></i> </button>
                        <button id="reject" type="submit" name="reject" onclick="return confirm('Do you want to delete this appointment?')" class="btn btn-outline-info btn-circle btn-lg btn-circle ml-2"><i class="fa fa-close"></i> </button>
                            </div>
                      </td>
            </form>
                    </tr>
                    <?php 
                    }
                    }else{
                        echo '<script> alert("No Pending Requests"); </script>';
                    }
                    ?>
                  </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" tabindex="-1" data-bs-backdrop="static" id="event-details-modal-req">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-0">
                <div class="modal-header rounded-0">
                    <h5 class="modal-title">Edit Schedule Details</h5>
                    <button type="button" class="btn-close" id="view_close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body rounded-0">
                    <div class="container-fluid">
                    <form action="save_schedule.php" method="post" id="schedule-form">
                                <input type="hidden" name="id" value="">
                                <div class="form-group mb-2">
                                    <label for="start_datetime" class="control-label">Start</label>
                                    <input type="datetime-local" class="form-control form-control-sm rounded-0" name="start_datetime" id="start_datetime" required>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="end_datetime" class="control-label">End</label>
                                    <input type="datetime-local" class="form-control form-control-sm rounded-0" name="end_datetime" id="end_datetime" required>
                                </div>
                            </form>
                    </div>
                </div>
                <div class="modal-footer rounded-0">
                            <div class="text-center">
                                <button class="btn btn-primary btn-sm rounded-0" type="submit" form="schedule-form"><i class="fa fa-save"></i> Save</button>
                                <button class="btn btn-default border btn-sm rounded-0" type="reset" form="schedule-form"><i class="fa fa-reset"></i> Cancel</button>
                            </div>
                </div>
            </div>
        </div>
    </div>



<style type="text/css">
body{
    background: #edf1f5;
    margin-top:20px;
}
.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 0 solid transparent;
    border-radius: 0;
}
.btn-circle.btn-lg, .btn-group-lg>.btn-circle.btn {
    width: 50px;
    height: 50px;
    padding: 14px 15px;
    font-size: 18px;
    line-height: 23px;
}
.text-muted {
    color: #8898aa!important;
}
[type=button]:not(:disabled), [type=reset]:not(:disabled), [type=submit]:not(:disabled), button:not(:disabled) {
    cursor: pointer;
}
.btn-circle {
    border-radius: 100%;
    width: 40px;
    height: 40px;
    padding: 10px;
}
.user-table tbody tr .category-select {
    max-width: 150px;
    border-radius: 20px;
}

</style>

<script type="text/javascript">
    $('#edit_req').click(function() {
            $('#event-details-modal-req').modal('show')
    })

    $('#view_close').click(function() {
        $('#event-details-modal-req').modal('hide')
    })

    $('#schedule-form').on('reset', function() {
        $(this).find('input:hidden').val('')
        $(this).find('input:visible').first().focus()
    })
    // function req_reject(){
    //     var status = confirm("Do you want to delete this appointment?");
    // <?php //if(isset($_POST['reject'])){
    // $req_id = $_GET['r_id']; ?>
    //     if (status) {
    //         <?php 
    //         $query = "DELETE FROM request where r_id = '$req_id'";
    //         if(performQuery($query)){
    //         echo "<script> alert('Appointment removed!'); 
    //                 location.replace('app_request.php') </script>";

    //         }
    //         else{
    //             echo "Unknown Error Occuered.";
    //             } ?>   
    //     } 
        
    //     <?php //} ?>
    // }    

</script>

<?php 

$id1 = $_SESSION['stu_id'];

$sql1 = "select * from request";
$app = mysqli_query($con,$sql1);

if($app && mysqli_num_rows($app) > 0){

    $req_result = mysqli_fetch_assoc($app);
    $stu_id = $req_result['stu_id'];
}
if(isset($_POST['submit'])){
    $id = $_GET['AID'];
    $start_datetime= $_GET['start_datetime'];
    $end_datetime= $_GET['start_datetime'];
    $description= $_GET['description'];


    if($id == 0){
        $sql = "INSERT INTO `appointment` (`stu_id`,`description`,`start_datetime`,`end_datetime`, `lect_id`) VALUES ('$stu_id','$description','$start_datetime','$end_datetime', '$lec')";
    }
    else{
        $sql = "UPDATE `appointment` set `stu_id` = '{$stu_id}', `description` = '{$description}', `start_datetime` = '{$start_datetime}', `end_datetime` = '{$end_datetime}', `lect_id` = '{$id1}' where `AID` = '{$id}'";

    }

    $save = $con->query($sql);
    $del_id = $_GET['a_r_id'];
    if($save){
        echo "<script> alert('Appointment Accepted.'); </script>";
        $delete = "DELETE from advisee_request where a_r_id = '$del_id'";
        $delete_req = $con->query($delete);
        if($delete_req){
            echo "<script> location.replace('advisee_req.php') </script>";
        }

    }else{
        echo "<pre>";
        echo "An Error occured.<br>";
        echo "Error: ".$con->error."<br>";
        echo "SQL: ".$sql."<br>";
        echo "</pre>";
    }

}

if(isset($_POST['reject'])){
    $req_id = $_GET['a_r_id'];
    echo '<script type="\text/javascript\">
    if (confirm("Do you want to delete this appointment?") == true) {
    </script>';
    $query = "DELETE FROM advisee_request where a_r_id = '$req_id'";
        if(performQuery($query)){
            echo "<script> alert('Appointment removed!'); 
                    location.replace('advisee_req.php') </script>";

        }
        else{
            echo "Unknown Error Occuered.";
        }
    }
       
        

// }



$con->close();
?>
</body>
<script src="script.js"></script>

</html>