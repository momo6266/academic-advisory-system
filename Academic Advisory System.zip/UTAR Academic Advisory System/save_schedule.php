<?php
session_start();

include('connection.php');
include('functions.php');


if($_SERVER['REQUEST_METHOD'] !='POST'){
    echo "<script> alert('Error: No data to save.'); location.replace('advisor.php?username=$username') </script>";
    $con->close();
    exit;
}
extract($_POST);
$allday = isset($allday);
$id1 = $_SESSION['lect_id'];

    if(empty($id)){
        $sql = "INSERT INTO `appointment` (`stu_id`,`description`,`start_datetime`,`end_datetime`, `lect_id`) VALUES ('$title','$description','$start_datetime','$end_datetime', '$id1')";
    }
    else{
        $sql = "UPDATE `appointment` set `stu_id` = '{$title}', `description` = '{$description}', `start_datetime` = '{$start_datetime}', `end_datetime` = '{$end_datetime}', `lect_id` = '{$id1}' where `AID` = '{$id}'";
    }

$save = $con->query($sql);
if($save){
    echo "<script> alert('Schedule Successfully Saved.'); location.replace('advisor.php?username=$username') </script>";
}else{
    echo "<pre>";
    echo "An Error occured.<br>";
    echo "Error: ".$con->error."<br>";
    echo "SQL: ".$sql."<br>";
    echo "</pre>";
}
$con->close();
?>