<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right:1px solid #bbb;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}

.active {
    background-color: #04AA6D;
}
.grapha {
    float: right;
    width: 45%;
}

</style>
</head>
<body>
    


<ul>
  <li style= "width: 9%"><a class="active" href="selectl.php">Select Student</a></li>
  <li class="grapha"><a href="performancel.php">Result Graph</a></li>
  <li class="grapha"><a href="subjectl.php">Subject Result</a></li>
</ul>

</body>
</html>
