<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Portal Login</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body>

<?php

$host = "localhost";  
$user = "root";  
$password = '';  
$db_name = "mydatabase";  
  
$con = mysqli_connect($host, $user, $password, $db_name);  
if(mysqli_connect_errno()) {  
    die("Failed to connect with MySQL: ". mysqli_connect_error());  
}

$StudentID = $_POST['StudentID'];
$username = $_POST['username'];
$session = $_POST['Session'];

$hour= $_POST['durationhour'];
$min= $_POST['durationmin'];
$duration= ($hour*60)+$min;
$date= $_POST['consultdate'];
$time= $_REQUEST['consulttime'];
$Academic_Performance= $_POST['academic'];
$Class_Attendance= $_POST['attendance'];
$Involvement= $_POST['curricular'];
$Overall_Performance= $_POST['overall'];
$Problems= $_POST['problems'];
$Advice= $_POST['advice'];
$Follow_Up= $_POST['follow-up'];
$Outcome= $_POST['outcome'];

$sql ="insert into report (Duration, Date, Time, Status, Session, Academic_Performance, Class_Attendance, Involvement, Overall_Performance, Problems, Advice, Follow_Up, Outcome)
values('$duration','$date','$time','0','$session','$Academic_Performance','$Class_Attendance','$Involvement','$Overall_Performance','$Problems','$Advice','$Follow_Up','$Outcome')";
$run = mysqli_query($con,$sql);
$sql ="insert into report_stu (StudentID) values('$StudentID')";
$run = mysqli_query($con,$sql);









//Email
$sql= "select * from stuinfo where StudentID = '$StudentID'";
$result = mysqli_query($con, $sql);
$row1 = mysqli_fetch_array($result, MYSQLI_ASSOC);

$to = $row1["University Email"];
$subject = "TO REVIEW & CONFIRM ON PENDING CONSULATION & COUNSELLING DETAILS";
$message = "Please be informed that your consulation & counselling details are pending for your confirmation. Please login to Student Intranet and then proceed to My Course --> Academic Adviser for further information. Thank you. ";
$headers="From:netaliewan0809@gmail.com";

mail($to,$subject,$message,$headers);


?>


<table>
    <tr><a href = "lectmainpage.php?username=<?php echo $username?>"><button class="btn btn-primary" type="button">Click here to return to main page.</tr>
</table>


</body>

</html>